﻿System.Random rnd = new System.Random();
int dice = rnd.Next(0, 7);
Console.WriteLine("You rolled " + dice);